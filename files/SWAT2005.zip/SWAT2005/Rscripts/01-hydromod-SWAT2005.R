################################################################################
## File 01-hydromod-SWAT2005.R                                                 #
## Part of the hydroPSO R package:                                             #
##                             http://www.rforge.net/hydroPSO/ ;               #
##                             http://cran.r-project.org/web/packages/hydroPSO #
## Copyright 2011-2012 Mauricio Zambrano-Bigiarini & Rodrigo Rojas             #
## Distributed under GPL 2 or later                                            #
##                                                                             #
## Example showing how to run SWAT-2005 with the 'hydromod' function, in order #
## to be calibrated with 'hydroPSO' in a subsequent step.                      #
##                                                                             #
## This script shows the definition of simple I/O R functions used to read the #
## model outputs and to compute the corresponding goodness-of-fit value, by    #
## comparing observations with its corresponding simulated counterparts        #
##                                                                             #
## After running the model with 'hydromod', the user have to check that:       #
##   -) the model effectively run once, and                                    #
##   -) the output is a list with 2 elements: simulated values and             #
##      the goodness-of-fit measure.                                           #
##                                                                             #
## NOTE:                                                                       #
## It is highly recommended to remove any previous model output file(s) before #
## running 'hydromod', in order to prevent reading a pre-existing output       #
## file(s) when the model did not run successfully                             #
##                                                                             #
##                                                                             #
## Created by Mauricio Zambrano-Bigiarini and Rodrigo Rojas. 24-Oct-2012       #
## Last update: 24-Oct-2012 ; 30-Jan-2012 ; 01-Feb-2013                        #
################################################################################

### Loading required libraries
library(hydroPSO)
library(hydroGOF)
library(hydroTSM)
library(SWAT2R)   # if not on CRAN, get it from http://www.rforge.net/SWAT2R/

### Definition of working directory: input, output and model file paths
model.drty <- "~/SWAT2005" 
setwd(model.drty)       # Only required for (Windows) users not running this 
                        # script from the system console
model.drty <- getwd()  

### Period of analysis
Sim.Ini="1962-01-01"
Sim.Fin="1965-12-31"
gof.Ini="1962-01-01"
gof.Fin="1965-12-31"

### Goodness-of-fit function, either customized or pre-defined from hydroGOF
gof.FUN <- "NSE"
gof.FUN.args <- list()

### Getting the OBSERVATIONS
obs.fname <- paste(model.drty,"/PSO.in/SWAT_obs.txt",sep="")
q.obs     <- read.zoo(obs.fname)

### Arguments required for running SWAT with the 'hydromod' function
model.FUN.args=list(
   model.drty=model.drty,
   
   param.files=paste(model.drty,"/PSO.in/ParamFiles.txt",sep=""), 
   
   exe.fname="./swat2005.out",  # GNU/Linux
   #exe.fname="./swat2005.exe", # Windows XP/Vista/7/...
   
   verbose=TRUE,             # To see on the screen each one of the 4(5) steps 
                             # carried out for running the model:
                             #   1) Parameter values -> Input files
                             #   2) Running the model exe file
                             #   3) Extracting simulated values
                             #   4) Computing the goodness of fit
                             # NOTE_1: This argument should be UNcommented until 
                             #         being sure the model is running properly
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented 
                             
   stdout="",                # To see on the screen the output of the model
                             # (if any).
                             # NOTE_1: This argument should be uncommented until 
                             #         being sure the model is running properly  
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented      
                                    
   ### Function for reading the simulated equivalents
   out.FUN="read_rch",
   out.FUN.args=list(
      file="output.rch",
      col.names="FLOW_OUTcms",
      out.type="Q",
      rchID=1,
      Date.Ini=Sim.Ini,
      Date.Fin=Sim.Fin,
      tstep="daily",
      verbose=FALSE
      ), ###END out.FUN.args
      
   ### Function for assessing the simulated equivalents against the observations
   gof.FUN=gof.FUN,
   gof.FUN.args=gof.FUN.args,
   gof.Ini=gof.Ini,
   gof.Fin=gof.Fin,
   obs=q.obs
) ###END model.FUN.args



################################################################################
###                       Running SWAT with hydromod                         ###
################################################################################

### Before running the model with 'hydromod', we recommend:
### 1) to remove all the model output files 
### 2) to overwrite all the SWAT-2005 input files (within 'model.drty') with  
###    those within the 'Backup' directory


# Test values for the 10 parameters selected to be calibrated
#                 CN2,  ESCO, SURLAG, ALPHA_BF, SOL_K, SOL_AWC, CH_N2,  CH_K2, SFTMP 
param.values <- c(56.1, 0.37, 8.12,   0.0696,   52.7,  0.221,   0.0267, 25.9,  2.73)
                                       

# Running the hydrological model with R, getting the model simulated values and
# its corresponding goodness-of-fit measure
out <- hydromod(
   param.values=param.values, # parameter values passed to the model 
        
   do.png=TRUE,               # to produce a PNG with 'sim' vs 'obs'
   png.fname="S090-png",      # name of the output PNG file
   main="S090-Test",          # title of the Figure with 'sim' vs 'obs'
        
   #############################################################################
   # From line 125 up to line 170, ALL arguments are EXACTLY the same as in 
   # 'model.FUN.args', previously defined in lines 55 up to 98
   model.drty=model.drty,
   
   param.files=paste(model.drty,"/PSO.in/ParamFiles.txt",sep=""), 
   
   exe.fname="./swat2005.out",  # GNU/Linux
   #exe.fname="./swat2005.exe", # Windows XP/Vista/7/...
   
   verbose=TRUE,             # To see on the screen each one of the 4(5) steps 
                             # carried out for running the model:
                             #   1) Parameter values -> Input files
                             #   2) Running the model exe file
                             #   3) Extracting simulated values
                             #   4) Computing the goodness of fit
                             # NOTE_1: This argument should be UNcommented until 
                             #         being sure the model is running properly
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented 
                             
   stdout="",                # To see on the screen the output of the model
                             # (if any).
                             # NOTE_1: This argument should be uncommented until 
                             #         being sure the model is running properly  
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented      
                                    
   ### Function for reading the simulated equivalents
   out.FUN="read_rch",
   out.FUN.args=list(
      file="output.rch",
      col.names="FLOW_OUTcms",
      out.type="Q",
      rchID=1,
      Date.Ini=Sim.Ini,
      Date.Fin=Sim.Fin,
      tstep="daily",
      verbose=FALSE
      ), ###END out.FUN.args
      
   ### Function for assessing the simulated equivalents against the observations
   gof.FUN=gof.FUN,
   gof.FUN.args=gof.FUN.args,
   gof.Ini=gof.Ini,
   gof.Fin=gof.Fin,
   obs=q.obs
) ### END hydromod
 
# Getting only the model outputs
out[["sim"]]

# Getting the goodness-of-fit measure corresponding to the previous model outputs
out[["GoF"]]
        
        





################################################################################
###               Calibration with hydroPSO - TEST ONLY                      ###
################################################################################

### Before starting the calibration, we suggest to overwrite all the SWAT-2005 
### input files with  those within the 'Backup' directory

### MAIN PSO ALGORITHM
### For hydroPSO (>=0.3-0) fine-tuning parameters, see Zambrano-Bigiarini and Rojas, 2013
set.seed(100)
hydroPSO(
   fn="hydromod",
   model.FUN="hydromod",        
   model.FUN.args=model.FUN.args,
   control=list(
      param.ranges="ParamRanges.txt",
      normalise=TRUE,
      MinMax="max",
      npart=4, # Just for testing if the optimisation runs correctly
      maxit=1, # Just for testing if the optimisation runs correctly
      reltol=1E-30, # Just to ensure 'maxit' is achieved
      Xini.type="lhs",
      Vini.type="lhs2011",
      lambda=1,
      c1=2.05,
      c2=2.05,
      use.IW=FALSE,
      use.CF=TRUE,   
      use.TVlambda=TRUE,TVlambda.type="linear",TVlambda.rng=c(1.0,0.5),TVlambda.exp=1,
      topology="random",K=11,
      boundary.wall="absorbing2011",
      write2disk=TRUE,
      REPORT=5,
      verbose=TRUE
   ) ###END control options
) ###END MAIN hydroPSO ALGORITHM

# Plotting the results
plot_results(MinMax="max", do.png=TRUE)
