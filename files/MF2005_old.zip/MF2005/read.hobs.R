read.hobs <- function(fname="M2.HOB",ncol=9,skip=2) {
  x <- read.table(file=fname,skip=skip,header=FALSE)
  x <- x[,ncol]
  return(x)
} 