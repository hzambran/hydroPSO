################################################################################
## File 02-LHOAT-SWAT2005.R                                                    #
## Part of the hydroPSO R package:                                             #
##                             http://www.rforge.net/hydroPSO/ ;               #
##                             http://cran.r-project.org/web/packages/hydroPSO #
## Copyright 2011-2012 Mauricio Zambrano-Bigiarini & Rodrigo Rojas             #
## Distributed under GPL 2 or later                                            #
##                                                                             #
## Example to interface SWAT-2005 with lhoat                                   #
##                                                                             #
## This script allows to carry out a sensitivity analysis of SWAT-2005 with    #
## Latin-Hypercube One-at-A-Time, by defining some simple I/O R scripts        #
##                                                                             #
## Created by Mauricio Zambrano-Bigiarini and Rodrigo Rojas. 26-Oct-2011       #
## Last updated: 13-Feb-2012 ; 12-Apr-2012 ; 17-Apr-2012                       #
##               30-Jan-2013                                                   #
################################################################################

### Loading required libraries
library(hydroPSO)
library(hydroGOF)
library(hydroTSM)
library(SWAT2R)   # if not on CRAN, get it from http://www.rforge.net/SWAT2R/

### Definition of working directory: input, output and model files paths
model.drty <- "~/SWAT2005"             
setwd(model.drty)
param.ranges <- paste(model.drty,"/PSO.in/ParamRanges-Sens.txt",sep="")

### Period of analysis (see "file.cio" SWAT file)
Sim.Ini="1962-01-01"
Sim.Fin="1965-12-31"
gof.Ini="1962-01-01"
gof.Fin="1965-12-31"

### Goodness-of-fit function, either customized or pre-defined from hydroGOF
gof.FUN <- "NSE"
gof.FUN.args <- list()

### Getting the OBSERVATIONS
q.obs <- read.zoo("./PSO.in/SWAT_obs.txt")


### Arguments required for running SWAT with the 'hydromod' function
### See the '01-hydromod-SWAT2005.R' file, for additional info
### NOTE: The values of 'verbose' and 'stdout' are different from those in the 
###       hydromod-SWAT2005.R file, in order to see only the calibration progress
###       on the output screen
model.FUN.args=list(
   model.drty=model.drty,
   param.files=paste(model.drty,"/PSO.in/ParamFiles-Sens.txt",sep=""),
   exe.fname="./swat2005.out",  # GNU/Linux
   #exe.fname="swat2005.exe",   # Windows XP/Vista/7/...verbose=FALSE,
   stdout=FALSE,
   verbose=FALSE,
   ###Function for reading the simulated equivalents                  
   out.FUN="read_rch",
   out.FUN.args=list(
      file="output.rch",
      col.names="FLOW_OUTcms",
      out.type="Q",                     
      rchID=1,
      Date.Ini=Sim.Ini,
      Date.Fin=Sim.Fin,
      tstep="daily"), ###END out.FUN.args                         
   ###Function assessing the simulated equivalents against the observations                  
   gof.FUN=gof.FUN,
   gof.FUN.args=gof.FUN.args,
   gof.Ini=gof.Ini,
   gof.Fin=gof.Fin,
   obs=q.obs
) ###END model.FUN.args


           
### Main Latin-Hypercube One-factor-At-a-Time Sensitivity Analysis
lhoat(
   fn="hydromod",
   model.FUN="hydromod",
   model.FUN.args=model.FUN.args,
   control=list(
      N=20,
      f=0.1,         
      drty.out="LH_OAT",
      param.ranges=param.ranges,                     
      gof.name=gof.FUN,
      do.plots=FALSE,
      write2disk=TRUE,
      verbose= TRUE) ###END control options
) ###END lhoat
