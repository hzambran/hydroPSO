################################################################################
## File 03-hydroPSO-SWAT2005.R                                                 #
## Part of the hydroPSO R package:                                             #
##                             http://www.rforge.net/hydroPSO/ ;               #
##                             http://cran.r-project.org/web/packages/hydroPSO #
## Copyright 2011-2012 Mauricio Zambrano-Bigiarini & Rodrigo Rojas             #
## Distributed under GPL 2 or later                                            #
##                                                                             #
## Example to interface SWAT-2005 with hydroPSO (>=0.3-0)                      #
##                                                                             #
## This script allows hydroPSO to take control over the execution of SWAT-2005 #
## through the definition of simple I/O R scripts                              #
##                                                                             #
## Created by Mauricio Zambrano-Bigiarini and Rodrigo Rojas. 26-Oct-2011       #
## Last update: 12-Apr-2012 ; 13-Feb-2012 ;  17-Apr-2012                       #
##              30-Jan-2013                                                    #
################################################################################

### Loading required libraries
library(hydroPSO)
library(hydroGOF)
library(hydroTSM)
library(SWAT2R)   # if not on CRAN, get it from http://www.rforge.net/SWAT2R/

### Definition of working directory: input, output and model file paths
model.drty <- "~/SWAT2005" 
setwd(model.drty)       # Only required for (Windows) users not running this 
                        # script from the system console
model.drty <- getwd()

### Period of analysis
Sim.Ini="1962-01-01"
Sim.Fin="1965-12-31"
gof.Ini="1962-01-01" 
gof.Fin="1965-12-31"

### Goodness-of-fit function, either customized or pre-defined from hydroGOF
gof.FUN <- "NSE"
gof.FUN.args <- list()

### Parallel computations ?
  parallel <- "none"            # No parallel computations
  #parallel <- "multicore"      # GNU/Linux, UNIX only. For multi-core machines only
  #parallel <- "parallel"       # GNU/Linux, UNIX only. For multi-core machines and network clusters
  #parallel <- "parallelWin"    # Windows & other OS.   For multi-core machines and network clusters

  # Number of cores/nodes desired
  par.nnodes <- 8

  # OPTIONAL. Only required for parallel=="parallelWin"   
  # packages that have to be loaded in each core or node of the network cluster
  par.pkgs   <- c("hydroGOF", "hydroTSM", "SWAT2R") 

### Getting the OBSERVATIONS
obs.fname <- paste(model.drty,"/PSO.in/SWAT_obs.txt",sep="")
q.obs     <- read.zoo(obs.fname)

### Arguments required for running SWAT with the 'hydromod' function
### See the '01-hydromod-SWAT2005.R' file, for additional info
### NOTE: The values of 'verbose' and 'stdout' are different from those in the 
###       hydromod-SWAT2005.R file, in order to see only the calibration progress
###       on the output screen
model.FUN.args=list(
   model.drty=model.drty,
   
   param.files=paste(model.drty,"/PSO.in/ParamFiles.txt",sep=""), 
   
   exe.fname="./swat2005.out",  # GNU/Linux
   #exe.fname="./swat2005.exe", # Windows XP/Vista/7/...
   
   verbose=FALSE,            # To see on the screen each one of the 4(5) steps 
                             # carried out for running the model:
                             #   1) Parameter values -> Input files
                             #   2) Running the model exe file
                             #   3) Extracting simulated values
                             #   4) Computing the goodness of fit
                             # NOTE_1: This argument should be UNcommented until 
                             #         being sure the model is running properly
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented 
                             
   #stdout="",               # To see on the screen the output of the model
                             # (if any).
                             # NOTE_1: This argument should be uncommented until 
                             #         being sure the model is running properly  
                             # NOTE_2: For the model calibration with hydroPSO 
                             #         this argument should be commented      
                                    
   ### Function for reading the simulated equivalents
   out.FUN="read_rch",
   out.FUN.args=list(
      file="output.rch",
      col.names="FLOW_OUTcms",
      out.type="Q",
      rchID=1,
      Date.Ini=Sim.Ini,
      Date.Fin=Sim.Fin,
      tstep="daily",
      verbose=FALSE
      ), ###END out.FUN.args
      
   ### Function for assessing the simulated equivalents against the observations
   gof.FUN=gof.FUN,
   gof.FUN.args=gof.FUN.args,
   gof.Ini=gof.Ini,
   gof.Fin=gof.Fin,
   obs=q.obs
) ###END model.FUN.args


################################################################################
###                     Calibration with hydroPSO                            ###
################################################################################

### Before starting the calibration, we suggest to overwrite all the SWAT-2005 
### input files (within 'model.drty')) with  those within the 'Backup' directory

### MAIN PSO ALGORITHM
### For hydroPSO fine-tuning parameters, see Zambrano-Bigiarini and Rojas, 2013
set.seed(100)
system.time(
hydroPSO(
   fn="hydromod",
   model.FUN="hydromod",        
   model.FUN.args=model.FUN.args,
   control=list(
      param.ranges="ParamRanges.txt",
      normalise=TRUE,
      MinMax="max",
      npart=40,
      maxit=100, # try maxit=500
      reltol=1E-30, # Just to ensure 'maxit' is achieved
      Xini.type="lhs",
      Vini.type="lhs2011",
      lambda=1,
      c1=2.05,
      c2=2.05,
      use.IW=FALSE,
      use.CF=TRUE,   
      use.TVlambda=TRUE,TVlambda.type="linear",TVlambda.rng=c(1.0,0.5),TVlambda.exp=1,
      topology="random", K=11, # try K=5 ... 
      boundary.wall="absorbing2011",
      write2disk=TRUE,
      REPORT=5,
      verbose=TRUE,
      
      parallel=parallel,
      par.nnodes=par.nnodes,
      par.pkgs=par.pkgs
   ) ###END control options
) ###END MAIN hydroPSO ALGORITHM
)

# Plotting the results
plot_results(do.png=TRUE, MinMax="max", ftype="dm", do.pairs=TRUE, legend.pos="topleft")
