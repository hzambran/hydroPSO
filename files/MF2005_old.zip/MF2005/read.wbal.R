read.wbal <- function(fname="M2.BAL") {

if (length(readLines(fname)) > 34 ) {
  suppressWarnings(rechdeep <- as.numeric(read.table(file=fname,skip=34,header=FALSE,nrows=1,colClasses=c("NULL","NULL","numeric"),fill=TRUE)))
  suppressWarnings(cgordo <- as.numeric(read.table(file=fname,skip=42,header=FALSE,nrows=1,colClasses=c("NULL","NULL","NULL","NULL","NULL","numeric"),fill=TRUE)))
  noria <- NA
  chaca <- NA

  x <- readLines(fname)
  stg <- "     Flow Budget for Zone  5 at Time Step  1 of Stress Period  1"
  n <- which(x==stg)
  L <- length(n)
  if (L > 0) noria <- read.table(file=fname,skip=n+18,header=FALSE,nrows=1,colClasses=c("NULL","NULL","numeric"),fill=TRUE)

  stg <- "     Flow Budget for Zone 16 at Time Step  1 of Stress Period  1"
  n <- which(x==stg)
  L <- length(n)
  if (L > 0) chaca <- read.table(file=fname,skip=n+8,header=FALSE,nrows=1,colClasses=c("NULL","NULL","numeric"),fill=TRUE)
  out <- c(rechdeep,noria,cgordo,chaca)
} else out <- rep(NA,4)
names(out) <- c("rechdeep","noria","cgordo","chaca")
return(out)
}
     
     