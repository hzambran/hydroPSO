################################################################################
## File hydroPSO-SWAT2005.R                                                    #
## Part of the hydroPSO R package:                                             #
##                             http://www.rforge.net/hydroPSO/ ;               #
##                             http://cran.r-project.org/web/packages/hydroPSO #
## Copyright 2011-2012 Mauricio Zambrano-Bigiarini & Rodrigo Rojas             #
## Distributed under GPL 2 or later                                            #
##                                                                             #
## Example to interface SWAT-2005 with hydroPSO. This script allows hydroPSO   #
## to take control over the execution of SWAT-2005 through the definition of   #
## simple I/O R scripts                                                        #
##                                                                             #
## Created by Mauricio Zambrano-Bigiarini and Rodrigo Rojas. 26-Oct-2011       #
## Last saved: 13-Feb-2012 ; 12-Apr-2012 ; 17-Apr-2012                         #
################################################################################

###Loading required libraries
library(hydroPSO)
library(hydroGOF)
library(hydroTSM)
library(SWAT2R)   # if not on CRAN, get it from http://www.rforge.net/SWAT2R/

###Definition of working directory: input, output and model files paths
model.drty <- "~/SWAT2005"
setwd(model.drty)

###Period of analysis
Sim.Ini="1962-01-01"
Sim.Fin="1965-12-31"
gof.Ini="1962-01-01"
gof.Fin="1965-12-31"

###Goodness-of-fit function, either customized or pre-defined from hydroGOF
gof.FUN <- "NSE"
gof.FUN.args <- list()

###Getting the OBSERVATIONS
q.obs <- read.zoo("./PSO.in/SWAT_obs.txt")

###MAIN model function
model.FUN.args=list(
   model.drty=model.drty,
   param.files=paste(model.drty,"/PSO.in/ParamFiles.txt",sep=""), 
   #exe.fname="./swat2005.out",# GNU/Linux
   exe.fname="swat2005.exe", # Windows XP/Vista/7/...
   #verbose=TRUE,             # To see  on the screen which parameters are changed
   #stdout="",            
   ###Function for reading the simulated equivalents
   out.FUN="read_rch",
   out.FUN.args=list(
      file="output.rch",
      col.names="FLOW_OUTcms",
      out.type="Q",
      rchID=1,
      Date.Ini=Sim.Ini,
      Date.Fin=Sim.Fin,
      tstep="daily",
      verbose=FALSE), ###END out.FUN.args
   ###Function for assessing the simulated equivalents against the observations
   gof.FUN=gof.FUN,
   gof.FUN.args=gof.FUN.args,
   gof.Ini=gof.Ini,
   gof.Fin=gof.Fin,
   obs=q.obs
) ###END model.FUN.args

### Before starting the calibration, we suggest to overwrite all the SWAT-2005 
### input files with  those within the 'Backup' directory

### MAIN PSO ALGORITHM
### For hydroPSO fine-tuning parameters, see Zambrano-Bigiarini and Rojas, 2012
set.seed(100)
hydroPSO(
   fn="hydromod",
   model.FUN="hydromod",        
   model.FUN.args=model.FUN.args,
   control=list(
      param.ranges="ParamRanges.txt",
      MinMax="max",
      npart=20,
      maxit=100,
      lambda=1,
      c2=0.5+log(2),
      use.IW=TRUE,IW.type="linear",IW.w=1/(2*log(2)),IW.exp=1,     
      use.TVc1=TRUE,TVc1.type="non-linear",TVc1.rng=c(1.28,1.05),TVc1.exp=1.5,
      use.TVlambda=TRUE,TVlambda.type="linear",TVlambda.rng=c(1.0,0.5),TVlambda.exp=1,
      topology="random",K=3,
      boundary.wall="reflecting",
      write2disk=TRUE,
      REPORT=5,
      verbose=TRUE
   ) ###END control options
) ###END MAIN hydroPSO ALGORITHM

# Plotting the results
plot_results(MinMax="max", do.png=TRUE)
