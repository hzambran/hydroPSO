read.hsim <- function(fname="M2.LST",nobs=42) {
sim <- rep(NA, nobs)
lik <- NA
out <- rep(NA,7)
L <- 0
x <- readLines(fname)
stg <- " HEAD AND DRAWDOWN OBSERVATIONS"
n <- which(x==stg)
L <- length(n)

if (L > 0) {
  suppressWarnings(tmp <- read.table(file=fname,skip=n+3,header=FALSE,nrows=nobs,colClasses=c("NULL","NULL","numeric","numeric"),fill=TRUE,na.strings="OMITTED"))
  sim <- as.numeric(tmp[,1])  
  res1 <- as.numeric(tmp[,2]) 
  na.index <- which(is.na(sim))
  
  if ((length(sim)==nobs) & (length(na.index)==0)) {
  
    # Gaussian likelihood (stdev = 10 same for MCMC analysis Rojas et al. 2010)
    gauss1 <- 2*pi
    gauss2 <- 10*sqrt(gauss1)
    gauss3 <- 1/gauss2
    gauss4 <- 2*(10^2)
    res2 <- res1^2
    lik1 <- gauss3*exp(-(res2/gauss4))
    lik2 <- prod(lik1)
    lik <- lik2^(1/nobs) #likelihood using "product" inference function (Rojas et al. 2010)
	
	system2("zonbud_hydroPSO.exe")
    stg <- "  VOLUMETRIC BUDGET FOR ENTIRE MODEL AT END OF TIME STEP  1 IN STRESS PERIOD   1"
    n <- which(x==stg)         
    L <- length(n)             
    if (L > 0) {
      suppressWarnings(tmp <- read.table(file=fname,skip=n+11,header=FALSE,nrows=9,fill=TRUE,stringsAsFactors=FALSE))
      rech <-as.numeric(tmp[1,3])
      evap <-as.numeric(tmp[8,3])
      transp <-as.numeric(tmp[9,3])
      out1 <- c(rech,evap,transp )
      names(out1) <- c("rech","evap","transp")
      out2 <- read.wbal("M2.BAL")
      out <- c(out1, out2)
    }
  } else {
      sim <- rep(NA, nobs)
      lik <- NA
      out <- rep(NA,7)
    }
}

# Adding the results of the water balance to "WBAL.txt"
wb.Text.file <- file("WBAL.txt","a")
writeLines(as.character(out),wb.Text.file,sep=" ")
writeLines("",wb.Text.file)
close(wb.Text.file)   
write(lik,"lik_gauss.txt")
return(sim)
}